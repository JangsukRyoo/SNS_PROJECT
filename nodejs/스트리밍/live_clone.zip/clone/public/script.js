const socket = io('/')
const myVideoGrid = document.getElementById('Myvideo')
const video = document.getElementsByTagName('video')
const stopvideo = document.getElementById('stopvideo')
const playvideo = document.getElementById('playvideo')
const muted = document.getElementById('muted')
const unmuted = document.getElementById('unmuted')

const myPeer = new Peer(undefined, {
}

)
let myVideoStream
const myVideo = document.createElement('video')
myVideo.muted = true
const peers = {}
var getUserMedia = null
getUserMedia = navigator.mediaDevices.getUserMedia({
  video: true,
  audio: true
}).then(stream => {
  addVideoStream(myVideo, stream)
  myVideoStream = stream;
  myPeer.on('call', call => {
    console.log('myPeer call 실행')
    call.answer(stream)
    const video = document.createElement('video')

    call.on('stream', userVideoStream => {
      console.log('call.on(stream) 실행')
      addVideoStream(video, userVideoStream)
    })
  })


  socket.on('user-connected', userId => {
    console.log('socket.on user-connected실행')
    connectToNewUser(userId, stream)
  })
})


socket.on('user-disconnected', userId => {
  console.log('socket.on user-disconnected실행')
  if (peers[userId]) peers[userId].close()
})

myPeer.on('open', id => {
  console.log('mypeer.on open실행')
  socket.emit('join-room', ROOM_ID, id)
})

function connectToNewUser(userId, stream) {
  console.log('function connectToNewUser 실행')
  const call = myPeer.call(userId, stream)
  const video = document.createElement('video')
 

  call.on('stream', userVideoStream => {
    console.log('function connectToNewUser 안 call.on  stream 실행')
    addVideoStream(video, userVideoStream)
  })
  call.on('close', () => {
    console.log('call.on실행')
    video.remove()
  })

  peers[userId] = call
}

function addVideoStream(video, stream) {
  video.srcObject = stream
  video.addEventListener('loadedmetadata', () => {
    video.play()
  })
  
  myVideoGrid.append(video)

}

function stopVideo() {
  myVideoStream.getVideoTracks()[0].enabled = false;
  stopvideo.style.display = 'none';
  playvideo.style.display = '';
  video[0].style.color = "black";
}

function playVideo() {
  myVideoStream.getVideoTracks()[0].enabled = true;
  playvideo.style.display = 'none';
  stopvideo.style.display = '';
}

function mute() {
  myVideoStream.getAudioTracks()[0].enabled = false;
  muted.style.display = 'none';
  unmuted.style.display = '';
}

function unmute() {
  myVideoStream.getAudioTracks()[0].enabled = true;
  unmuted.style.display = 'none';
  muted.style.display = '';
}




